package cgopkg

import "C"

import (
	_ "golang.org/x/mobile/gl"
)

func Dummy() {}
