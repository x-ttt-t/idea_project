goutil is a collection of misc Go utility code that is potentially useful
across multiple projects, and has therefore been factored out.
