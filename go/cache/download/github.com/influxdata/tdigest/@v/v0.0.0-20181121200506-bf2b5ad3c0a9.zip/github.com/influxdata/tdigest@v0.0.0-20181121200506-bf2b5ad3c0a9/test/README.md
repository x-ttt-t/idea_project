# Testing

This directory contains two programs `main.go` and `main.cpp` which both read three input file compute various quantiles and write out their results.
The purpose of these programs is to show that the Go implementaion is accurate as compared to the C++ implementaion.

The tests can be run using `test.sh`.

