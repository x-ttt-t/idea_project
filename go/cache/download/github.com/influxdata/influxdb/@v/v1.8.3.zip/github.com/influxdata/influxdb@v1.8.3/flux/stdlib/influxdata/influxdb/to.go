package influxdb

// TODO(jsternberg): Implement the to method in influxdb 1.x.
// This file is kept around so it shows up in the patch.
