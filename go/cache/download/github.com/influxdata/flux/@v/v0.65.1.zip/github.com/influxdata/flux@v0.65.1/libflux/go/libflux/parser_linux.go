package libflux

// #cgo LDFLAGS: -ldl
import "C"
