# Flux Examples

This folder contains a list of usage examples related to the Flux repo.

- [library](library): Use Flux as a standalone library in your Go programs.
