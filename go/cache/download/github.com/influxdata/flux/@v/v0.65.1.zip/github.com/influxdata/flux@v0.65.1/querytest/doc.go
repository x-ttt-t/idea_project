// Package querytest contains utilities for testing the query end-to-end.
package querytest
