package main

import "github.com/influxdata/flux/internal/cmd/fbgen/cmd"

func main() {
	cmd.Execute()
}
