
### Done checklist
- [ ] docs/SPEC.md updated
- [ ] Test cases written
