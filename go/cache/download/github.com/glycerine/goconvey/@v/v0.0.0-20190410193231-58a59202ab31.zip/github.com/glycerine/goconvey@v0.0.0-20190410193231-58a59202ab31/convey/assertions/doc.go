// Package assertions contains the implementations for all assertions which
// are referenced in the convey package for use with the So(...) method.
package assertions
