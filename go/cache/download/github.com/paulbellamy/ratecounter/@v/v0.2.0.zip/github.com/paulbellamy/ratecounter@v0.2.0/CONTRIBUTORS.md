RateCounter Contributors (sorted alphabetically)
============================================

- **[cheshir](https://github.com/cheshir)**

  - Added averate rate counter

- **[paulbellamy](https://github.com/paulbellamy)**

  -  Original implementation and general housekeeping

- **[sheerun](https://github.com/sheerun)**

  - Improved memory efficiency
