// Copyright 2016 go-fuzz project authors. All rights reserved.
// Use of this source code is governed by Apache 2 LICENSE that can be found in the LICENSE file.

// Test for fuzzing of internal packages.

package test

func Fuzz(data []byte) int {
	return 0
}
