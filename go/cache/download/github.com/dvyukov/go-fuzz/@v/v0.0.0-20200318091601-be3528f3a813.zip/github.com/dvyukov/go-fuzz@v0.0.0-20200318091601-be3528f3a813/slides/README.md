# go-fuzz presentations

- [go-fuzz: randomized testing system for Go](http://go-talks.appspot.com/github.com/dvyukov/go-fuzz/slides/go-fuzz.slide) (extended version of GopherCon 2015 talk)
- [Fuzzing: the new unit testing](http://go-talks.appspot.com/github.com/dvyukov/go-fuzz/slides/fuzzing.slide) (GopherCon Russia 2018)
