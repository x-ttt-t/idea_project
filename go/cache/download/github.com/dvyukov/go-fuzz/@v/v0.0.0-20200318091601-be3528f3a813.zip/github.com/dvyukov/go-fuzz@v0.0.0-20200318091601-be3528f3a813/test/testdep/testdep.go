// Copyright 2018 go-fuzz project authors. All rights reserved.
// Use of this source code is governed by Apache 2 LICENSE that can be found in the LICENSE file.

package testdep

type (
	I  interface{}
	B  bool
	V1 struct{}
	V2 struct{}
)
