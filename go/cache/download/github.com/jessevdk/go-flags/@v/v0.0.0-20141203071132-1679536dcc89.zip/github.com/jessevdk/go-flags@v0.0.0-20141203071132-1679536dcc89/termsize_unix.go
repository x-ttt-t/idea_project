// +build darwin freebsd netbsd openbsd

package flags

const (
	tIOCGWINSZ = 0x40087468
)
