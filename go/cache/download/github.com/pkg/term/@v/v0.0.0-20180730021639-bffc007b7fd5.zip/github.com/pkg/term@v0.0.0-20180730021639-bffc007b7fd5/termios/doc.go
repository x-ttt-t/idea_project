// Package termios implements the low level termios(3) terminal line discipline facilities.
//
// For a higher level interface please use the github.com/pkg/term package.
package termios
